import java.io.IOException;
import java.util.Map;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import counselorDAO.ViewCounselorAppointment_DAO;
import java.util.List;
import javax.servlet.http.HttpSession;

@WebServlet("/ViewCounselorAppointmentsServlet")
public class ViewCounselorAppointmentsServlet extends HttpServlet {

    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
   
        
        HttpSession session = request.getSession();
        String counselorID = (String) session.getAttribute("userID");

        if (counselorID == null) {
            response.sendRedirect("login.jsp?error=login");
            return;
        }

        ViewCounselorAppointment_DAO dao = new ViewCounselorAppointment_DAO();
        String action = request.getParameter("action");
        String appId = request.getParameter("appID");

      
        if ("markDone".equals(action) && appId != null) {
            dao.updateStatusToDone(appId);
            
            response.sendRedirect("viewAppointmentsCounselor.jsp");
            return;
        }

        List<Map<String, Object>> appointments = dao.getAppointmentsByCounselor(counselorID);
        

        request.setAttribute("appointmentsList", appointments);
        
        
        request.getRequestDispatcher("viewAppointmentsCounselor.jsp").forward(request, response);
        
       
    }
}