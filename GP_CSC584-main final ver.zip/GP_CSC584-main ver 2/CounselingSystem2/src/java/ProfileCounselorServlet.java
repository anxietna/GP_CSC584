import java.io.IOException;
import java.util.Map;
import java.sql.*;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import counselorDAO.ProfileCounselor_DAO; 

@WebServlet("/ProfileCounselorServlet")
public class ProfileCounselorServlet extends HttpServlet {

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        String userID = (String) session.getAttribute("userID");

        if (userID == null) {
            response.sendRedirect("login.jsp?error=login");
            return;
        }

      
        ProfileCounselor_DAO dao = new ProfileCounselor_DAO();
        Map<String, String> profile = dao.getCounselorProfile(userID);

 
        session.setAttribute("cName", profile.get("cName"));
        session.setAttribute("cEmail", profile.get("cEmail"));
        session.setAttribute("cPass", profile.get("cPass"));
        session.setAttribute("cSpec", profile.get("cSpec"));
        session.setAttribute("cOffice", profile.get("cOffice"));

 
        response.sendRedirect("profileCounselor.jsp" + (request.getQueryString() != null ? "?" + request.getQueryString() : ""));
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        String userID = (String) session.getAttribute("userID");
        
        String newName = request.getParameter("name");
        String newEmail = request.getParameter("email");
        String newPass = request.getParameter("password");
        String newSpec = request.getParameter("specialization");
        String newOffice = request.getParameter("office");

        ProfileCounselor_DAO dao = new ProfileCounselor_DAO();
        boolean success = dao.updateProfile(userID, newName, newEmail, newPass, newSpec, newOffice);

        if (success) {
            session.setAttribute("userName", newName);
            response.sendRedirect("ProfileCounselorServlet?update=success");
        } else {
            response.sendRedirect("ProfileCounselorServlet?update=error");
        }
    }
}