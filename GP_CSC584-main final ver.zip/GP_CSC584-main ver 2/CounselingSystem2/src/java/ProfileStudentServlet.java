import java.io.IOException;
import java.sql.*;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import studentDAO.ProfileStudent_DAO;

@WebServlet("/ProfileStudentServlet")
public class ProfileStudentServlet extends HttpServlet {


    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        String userID = (String) session.getAttribute("userID");

        if (userID == null) {
            response.sendRedirect("index.jsp?error=login");
            return;
        }
        

        ProfileStudent_DAO dao = new ProfileStudent_DAO();
        Map<String, String> profile = dao.getStudentProfile(userID);
        
        request.setAttribute("studentName", profile.get("studentName"));
        request.setAttribute("studentEmail", profile.get("studentEmail"));
        request.setAttribute("studentPassword", profile.get("studentPassword"));
        
        response.sendRedirect("profileStudent.jsp" + (request.getQueryString() != null ? "?" + request.getQueryString() : ""));
    }
    
     protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        HttpSession session = request.getSession();
        String userID = (String) session.getAttribute("userID");
        
        String newName = request.getParameter("name");
        String newEmail = request.getParameter("email");
        String newPass = request.getParameter("password");

        ProfileStudent_DAO dao = new ProfileStudent_DAO();
        boolean success = dao.updateProfile(userID, newName, newEmail, newPass);

        if (success) {
            session.setAttribute("userName", newName);
            response.sendRedirect("ProfileStudentServlet?update=success");
        } else {
            response.sendRedirect("ProfileStudentServlet?update=error");
        }
    }
}
     