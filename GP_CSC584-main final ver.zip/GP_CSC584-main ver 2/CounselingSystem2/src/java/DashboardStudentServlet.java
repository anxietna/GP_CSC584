import java.io.IOException;
import java.sql.*;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import studentDAO.dashboardStudent_DAO;
import studentDAO.viewAppointment_DAO;
import counseling.bean.AppointmentBean;

@WebServlet("/DashboardStudentServlet")
public class DashboardStudentServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String userID = (String) session.getAttribute("userID");
        String userRole = (String) session.getAttribute("userRole");

        if (userID == null || !"Student".equals(userRole)) {
            response.sendRedirect("index.jsp?error=login");
            return;
        }
        
        dashboardStudent_DAO dao = new dashboardStudent_DAO();
        Map<String, Object> data= dao.getDashboardData(userID);
        
        if(data != null){
            for(Map.Entry<String, Object> entry: data.entrySet()){
                session.setAttribute(entry.getKey(), entry.getValue());
            }
        }
        
        studentDAO.viewAppointment_DAO appDAO = new studentDAO.viewAppointment_DAO();
        java.util.List<AppointmentBean> appointments = appDAO.getAppointmentsByStudent(userID);
        
        AppointmentBean next = null;
        
        if(appointments != null && !appointments.isEmpty()) {
             for(AppointmentBean a :appointments){
                 if(!"Done".equalsIgnoreCase(a.getStatus().trim())) {
                     next = a;
                     break;
                 }
             }   
          
        }
        
        if(next != null) {
            session.setAttribute("nextCounselor", next.getCounselorName());
            session.setAttribute("nextDate", next.getDate());
            session.setAttribute("nextTime", next.getTime());
            session.setAttribute("nextLocation", next.getLocation());
        }
        else{
            session.removeAttribute("nextCounselor");
            session.removeAttribute("nextDate");
            session.removeAttribute("nextTime");
            session.removeAttribute("nextLocation");
        }
               
        response.sendRedirect("dashboardStudent.jsp");

    }  
}