


import java.io.IOException;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import counselorDAO.DashboardCounselor_DAO;

@WebServlet("/DashboardCounselorServlet")
public class DashboardCounselorServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        
        HttpSession session = request.getSession();
        String userID = (String) session.getAttribute("userID");

        if (userID == null) {
            response.sendRedirect("index.jsp?error=login");
            return;
        }

        DashboardCounselor_DAO dao = new DashboardCounselor_DAO();
        Map<String, Object> stats = dao.getDashboardStats(userID);

        if (stats != null && !stats.isEmpty()) {
            for (Map.Entry<String, Object> entry : stats.entrySet()) {
                session.setAttribute(entry.getKey(), entry.getValue());
            }
        }

        response.sendRedirect("dashboardCounselor.jsp");
    }
}
    
