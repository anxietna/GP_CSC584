import counseling.bean.AppointmentBean;
import studentDAO.viewAppointment_DAO;
import java.util.List;
import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import javax.servlet.ServletException;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/ViewAppointmentsServlet")
public class ViewAppointmentsServlet extends HttpServlet {



    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userID") == null) {
            response.sendRedirect("index.jsp");
            return;
        }
        
         String studentID = (String) session.getAttribute("userID");

        viewAppointment_DAO dao = new viewAppointment_DAO();
        List<AppointmentBean> appointments = dao.getAppointmentsByStudent(studentID);

        request.setAttribute("appointments", appointments);
        request.getRequestDispatcher("viewAppointments.jsp").forward(request, response);

      
    }
}
