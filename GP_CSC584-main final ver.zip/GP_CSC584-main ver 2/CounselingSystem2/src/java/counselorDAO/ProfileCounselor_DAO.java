package counselorDAO;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class ProfileCounselor_DAO {
    private final String dbURL = "jdbc:derby://localhost:1527/counselingDB";
    private final String dbUser = "app";
    private final String dbPass = "app";

    public Map<String, String> getCounselorProfile(String userID) {
        Map<String, String> profile = new HashMap<>();
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            try (Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPass)) {
                String sql = "SELECT * FROM COUNSELOR WHERE COUNSELORID = ?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, userID);
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    profile.put("cName", rs.getString("NAMECOUNS"));
                    profile.put("cEmail", rs.getString("EMAILCOUNS"));
                    profile.put("cPass", rs.getString("PASSWORDCOUNS"));
                    profile.put("cSpec", rs.getString("SPECIALIZATION"));
                    profile.put("cOffice", rs.getString("OFFICELOCATION"));
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
        return profile;
    }

    public boolean updateProfile(String userID, String name, String email, String pass, String spec, String office) {
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            try (Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPass)) {
                String sql = "UPDATE COUNSELOR SET NAMECOUNS=?, EMAILCOUNS=?, PASSWORDCOUNS=?, SPECIALIZATION=?, OFFICELOCATION=? WHERE COUNSELORID=?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, name);
                ps.setString(2, email);
                ps.setString(3, pass);
                ps.setString(4, spec);
                ps.setString(5, office);
                ps.setString(6, userID);
                return ps.executeUpdate() > 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
    
