import counseling.bean.StudentBean;
import studentDAO.registerStudent_DAO;
import java.io.*;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.annotation.WebServlet;

@WebServlet("/RegisterStudentServlet")

public class RegisterStudentServlet extends HttpServlet {


    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {


        StudentBean student = new StudentBean();
        student.setStudentID(request.getParameter("studentID"));
        student.setNameStud(request.getParameter("nameStud"));
        student.setUsernameStud(request.getParameter("usernameStud"));
        student.setPasswordStud(request.getParameter("passwordStud"));
        student.setEmailStud(request.getParameter("emailStud"));
        student.setMajorStud(request.getParameter("majorStud"));

        registerStudent_DAO dao = new registerStudent_DAO();

        boolean success = dao.registerStudent(student);

        if (success) {

            response.sendRedirect("register.jsp?success=true");
        } else {
            response.sendRedirect("register.jsp?error=true");
        }
        
    }
}
