package studentDAO;

import java.sql.*;
import counseling.bean.StudentBean;

public class registerStudent_DAO {
    
 private String dbURL = "jdbc:derby://localhost:1527/counselingDB";
    private String dbUser = "app";
    private String dbPass = "app";

    public boolean registerStudent(StudentBean student) {

        String sql = "INSERT INTO student (studentID, nameStud, usernameStud, passwordStud, emailStud, majorStud) "
                   + "VALUES (?, ?, ?, ?, ?, ?)";

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");

            Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPass);

            PreparedStatement ps = conn.prepareStatement(sql);

            ps.setString(1, student.getStudentID());
            ps.setString(2, student.getNameStud());
            ps.setString(3, student.getUsernameStud());
            ps.setString(4, student.getPasswordStud());
            ps.setString(5, student.getEmailStud());
            ps.setString(6, student.getMajorStud());

            int rows = ps.executeUpdate();

            ps.close();
            conn.close();

            return rows > 0; 

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
