package studentDAO;//

import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class StudentDAO {
    private String dbURL = "jdbc:derby://localhost:1527/counselingDB";
    private String dbUser = "app";
    private String dbPass = "app";

    public Map<String, Object> getDashboardData(String userID) {
        Map<String, Object> data = new HashMap<>();
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            try (Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPass)) {
                
                // 1. Get Appointment and Counselor Details
                String apptQuery = "SELECT a.statusBooking, a.dateAppointment, a.time, c.nameCouns, c.officeLocation " +
                                   "FROM appointment a JOIN counselor c ON a.counselorID = c.counselorID " +
                                   "WHERE a.studentID = ? ORDER BY a.dateAppointment ASC";
                
                PreparedStatement ps = conn.prepareStatement(apptQuery);
                ps.setString(1, userID);
                ResultSet rs = ps.executeQuery();

                int upcoming = 0; 
                int completed = 0;
                
                while (rs.next()) {
                    String status = rs.getString("statusBooking");
                    if ("Pending".equalsIgnoreCase(status)) {
                        upcoming++;
                        // Store only the first/next upcoming appointment details
                        if (!data.containsKey("nextDate")) {
                            data.put("nextDate", rs.getString("dateAppointment"));
                            data.put("nextTime", rs.getString("time"));
                            data.put("nextCounselor", rs.getString("nameCouns"));
                            data.put("nextLocation", rs.getString("officeLocation"));
                        }
                    } else if ("Done".equalsIgnoreCase(status) || "Completed".equalsIgnoreCase(status)) {
                        completed++;
                    }
                }
                data.put("upcomingCount", upcoming);
                data.put("completedCount", completed);

                // 2. Count Total Available Counselors
                PreparedStatement psCount = conn.prepareStatement("SELECT COUNT(*) FROM counselor");
                ResultSet rsCount = psCount.executeQuery();
                if (rsCount.next()) {
                    data.put("availableCounselors", rsCount.getInt(1));
                }
            }
        } catch (Exception e) {
            e.printStackTrace(); 
        }
        return data;
    }
}