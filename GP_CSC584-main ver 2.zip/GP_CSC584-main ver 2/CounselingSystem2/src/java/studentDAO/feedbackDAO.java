package studentDAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class feedbackDAO {

    private final String dbURL = "jdbc:derby://localhost:1527/counselingDB";
    private final String dbUser = "app";
    private final String dbPass = "app";

    public boolean saveOrUpdateFeedback(String appID, int rating, String comment) {

        Date feedbackDate = new Date(System.currentTimeMillis());

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");

            try (Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPass)) {


                String checkSql = "SELECT FEEDBACKID FROM FEEDBACK WHERE APPOINTMENTID=?";
                PreparedStatement checkPs = conn.prepareStatement(checkSql);
                checkPs.setString(1, appID);
                ResultSet rs = checkPs.executeQuery();

                String sql;
                if (rs.next()) {
                    // Update
                    sql = "UPDATE FEEDBACK SET RATING=?, COMMENT=?, FEEDBACKDATE=? WHERE APPOINTMENTID=?";
                } else {
                    // Insert
                    sql = "INSERT INTO FEEDBACK (RATING, COMMENT, FEEDBACKDATE, APPOINTMENTID) VALUES (?, ?, ?, ?)";
                }

                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setInt(1, rating);
                ps.setString(2, comment);
                ps.setDate(3, feedbackDate);
                ps.setString(4, appID);

                return ps.executeUpdate() > 0;
            }

        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}