package studentDAO;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import counseling.bean.FeedbackBean;

public class StudentFeedback_DAO {
    
    private final String dbURL = "jdbc:derby://localhost:1527/counselingDB";
    private final String dbUser = "app";
    private final String dbPass = "app";

    public List<FeedbackBean> getFeedbackByStudent(String studentID) {

    List<FeedbackBean> list = new ArrayList<>();
    
        String sql = "SELECT S.NAMESTUD, C.NAMECOUNS , F.RATING, F.COMMENT, F.FEEDBACKDATE " +
                     "FROM FEEDBACK F " +
                     "JOIN APPOINTMENT A ON F.APPOINTMENTID = A.APPOINTMENTID " +
                     "JOIN STUDENT S ON A.STUDENTID = S.STUDENTID " +
                     "JOIN COUNSELOR C ON A.COUNSELORID = C.COUNSELORID " +
                     "WHERE A.STUDENTID = ? " +
                     "AND A.STATUSBOOKING = 'Done'";

        try (Connection conn = DriverManager.getConnection( dbURL, dbUser, dbPass);
           
                PreparedStatement ps = conn.prepareStatement(sql)){
                    
                ps.setString(1, studentID);

                ResultSet rs = ps.executeQuery();



                while (rs.next()) {
                    FeedbackBean fb = new FeedbackBean();
                    fb.setStudentName(rs.getString("NAMESTUD"));
                    fb.setCounselorName(rs.getString("NAMECOUNS"));
                    fb.setRating(rs.getInt("RATING"));
                    fb.setComment(rs.getString("COMMENT"));
                    fb.setFeedbackDate(rs.getDate("FEEDBACKDATE"));

                    list.add(fb);
            }        
        

    } catch (Exception e) {
        e.printStackTrace();
    }

    return list;
    }      
}
