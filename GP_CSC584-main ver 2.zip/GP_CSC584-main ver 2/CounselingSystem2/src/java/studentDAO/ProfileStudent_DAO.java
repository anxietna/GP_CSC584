package studentDAO;

import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class ProfileStudent_DAO {
    private final String dbURL = "jdbc:derby://localhost:1527/counselingDB";
    private final String dbUser = "app";
    private final String dbPass = "app";

    // Method to fetch student profile
    public Map<String, String> getStudentProfile(String userID) {
        Map<String, String> profile = new HashMap<>();
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            try (Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPass)) {
                String sql = "SELECT * FROM STUDENT WHERE STUDENTID = ?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, userID);
                ResultSet rs = ps.executeQuery();

                if (rs.next()) {
                    profile.put("studentName", rs.getString("NAMESTUD"));
                    profile.put("studentEmail", rs.getString("EMAILSTUD"));
                    profile.put("studentPassword", rs.getString("PASSWORDSTUD"));
                }
            }
        } catch (Exception e) { e.printStackTrace(); }
        return profile;
    }

    // Method to update student profile
    public boolean updateProfile(String userID, String name, String email, String pass) {
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            try (Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPass)) {
                String sql = "UPDATE STUDENT SET NAMESTUD = ?, EMAILSTUD = ?, PASSWORDSTUD = ? WHERE STUDENTID = ?";
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, name);
                ps.setString(2, email);
                ps.setString(3, pass);
                ps.setString(4, userID);
                return ps.executeUpdate() > 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}