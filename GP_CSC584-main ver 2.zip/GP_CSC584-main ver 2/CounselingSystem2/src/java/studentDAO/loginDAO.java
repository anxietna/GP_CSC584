package studentDAO;
import java.sql.*;
import counseling.bean.StudentBean;
import counseling.bean.CounselorBean;

public class loginDAO {
    
 private String dbURL = "jdbc:derby://localhost:1527/counselingDB";
    private String dbUser = "app";
    private String dbPass = "app";

    public StudentBean loginStudent(String username, String password) {
        StudentBean student = null;

        String sql = "SELECT * FROM student WHERE usernameStud=? AND passwordStud=?";

        try (Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPass);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            Class.forName("org.apache.derby.jdbc.ClientDriver");

            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                student = new StudentBean();
                student.setStudentID(rs.getString("studentID"));
                student.setNameStud(rs.getString("nameStud"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return student;
    }

    public CounselorBean loginCounselor(String username, String password) {
        CounselorBean counselor = null;

        String sql = "SELECT * FROM counselor WHERE usernameCouns=? AND passwordCouns=?";

        try (Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPass);
             PreparedStatement ps = conn.prepareStatement(sql)) {

            Class.forName("org.apache.derby.jdbc.ClientDriver");

            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                counselor = new CounselorBean();
                counselor.setCounselorID(rs.getString("counselorID"));
                counselor.setNameCouns(rs.getString("nameCouns"));
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return counselor;
    }
}
