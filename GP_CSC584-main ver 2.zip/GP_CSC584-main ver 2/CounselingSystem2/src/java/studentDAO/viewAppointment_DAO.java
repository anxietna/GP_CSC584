package studentDAO;

import counseling.bean.AppointmentBean;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class viewAppointment_DAO {

    private String dbURL = "jdbc:derby://localhost:1527/counselingDB";
    private String dbUser = "app";
    private String dbPass = "app";

    public List<AppointmentBean> getAppointmentsByStudent(String studentID) {
        List<AppointmentBean> appointments = new ArrayList<>();

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            try (Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPass)) {

                String sql = "SELECT a.appointmentID, a.dateAppointment, a.time, a.statusBooking, a.reasonBooking, "
                           + "c.nameCouns, c.officeLocation "
                           + "FROM appointment a "
                           + "JOIN counselor c ON a.counselorID = c.counselorID "
                           + "WHERE a.studentID = ? "
                           //+ "AND a.statusBooking <> 'Done' "
                           + "ORDER BY a.dateAppointment ASC";

                try (PreparedStatement ps = conn.prepareStatement(sql)) {
                    ps.setString(1, studentID);
                    try (ResultSet rs = ps.executeQuery()) {
                        while (rs.next()) {
                            AppointmentBean ab = new AppointmentBean();
                            ab.setAppointmentID(rs.getString("appointmentID"));
                            ab.setDate(rs.getString("dateAppointment"));
                            ab.setTime(rs.getString("time"));
                            ab.setStatus(rs.getString("statusBooking"));
                            ab.setReason(rs.getString("reasonBooking"));
                            ab.setCounselorName(rs.getString("nameCouns"));
                            ab.setLocation(rs.getString("officeLocation"));
                            appointments.add(ab);
                        }
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        return appointments;
    }
}

