package studentDAO;

import java.sql.*;
import java.util.*;
import counseling.bean.AppointmentBean;


public class scheduleAppointment_DAO {

    private String dbURL = "jdbc:derby://localhost:1527/counselingDB";
    private String dbUser = "app";
    private String dbPass = "app";

    // Fetch all counselors
    public List<Map<String, String>> getAllCounselors() {
        List<Map<String, String>> counselors = new ArrayList<>();
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            try (Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPass)) {
                String sql = "SELECT counselorID, nameCouns FROM counselor";
                PreparedStatement ps = conn.prepareStatement(sql);
                ResultSet rs = ps.executeQuery();
                while (rs.next()) {
                    Map<String, String> c = new HashMap<>();
                    c.put("id", rs.getString("counselorID"));
                    c.put("name", rs.getString("nameCouns"));
                    counselors.add(c);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return counselors;
    }

    // Save appointment
    public boolean saveAppointment(AppointmentBean appointment, String studentID) {
        String sql = "INSERT INTO appointment (studentID, counselorID, dateAppointment, time, statusBooking, reasonBooking) "
                   + "VALUES (?, ?, ?, ?, ?, ?)";
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            try (Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPass)) {
                PreparedStatement ps = conn.prepareStatement(sql);
                ps.setString(1, studentID);
                ps.setString(2, appointment.getCounselorName()); // store counselorID
                ps.setString(3, appointment.getDate());
                ps.setString(4, appointment.getTime());
                //ps.setString(5, appointment.getLocation());
                ps.setString(5, "Pending"); // default
                ps.setString(6, appointment.getReason());
                int rows = ps.executeUpdate();
                return rows > 0;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }
}
