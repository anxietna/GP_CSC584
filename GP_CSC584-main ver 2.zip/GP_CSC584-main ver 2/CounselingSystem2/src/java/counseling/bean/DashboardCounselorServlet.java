package counseling.bean;


import java.io.IOException;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import counselorDAO.DashboardCounselor_DAO;

@WebServlet("/DashboardCounselorServlet")
public class DashboardCounselorServlet extends HttpServlet {
    
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        //request.getRequestDispatcher("dashboardCounselor.jsp").forward(request, response);
        
        HttpSession session = request.getSession();
        String userID = (String) session.getAttribute("userID");

        // Security Check
        if (userID == null) {
            response.sendRedirect("index.jsp?error=login");
            return;
        }

        // 1. Initialize DAO (For future stats/counters)
        DashboardCounselor_DAO dao = new DashboardCounselor_DAO();
        Map<String, Object> stats = dao.getDashboardStats(userID);

        // 2. Put stats into session if any exist
        if (stats != null && !stats.isEmpty()) {
            for (Map.Entry<String, Object> entry : stats.entrySet()) {
                session.setAttribute(entry.getKey(), entry.getValue());
            }
        }

        // 3. Redirect to JSP to show .jsp in the URL
        response.sendRedirect("dashboardCounselor.jsp");
    }
}
    
