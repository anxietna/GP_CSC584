package counseling.bean;

import java.io.IOException;
import java.util.Map;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import counselorDAO.ViewCounselorAppointment_DAO;
import java.util.List;
import javax.servlet.http.HttpSession;

@WebServlet("/ViewCounselorAppointmentsServlet")
public class ViewCounselorAppointmentsServlet extends HttpServlet {
    //private final String dbURL = "jdbc:derby://localhost:1527/counselingDB";
    
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        
        //String action = request.getParameter("action");
        //String appId = request.getParameter("appID");
        
        HttpSession session = request.getSession();
        String counselorID = (String) session.getAttribute("userID");

        if (counselorID == null) {
            response.sendRedirect("login.jsp?error=login");
            return;
        }

        ViewCounselorAppointment_DAO dao = new ViewCounselorAppointment_DAO();
        String action = request.getParameter("action");
        String appId = request.getParameter("appID");

        // 1. Process Update Action
        if ("markDone".equals(action) && appId != null) {
            dao.updateStatusToDone(appId);
            // Redirect back to the JSP URL to maintain clean browser URL
            response.sendRedirect("viewAppointmentsCounselor.jsp");
            return;
        }

        // 2. Fetch Data via DAO
        List<Map<String, Object>> appointments = dao.getAllAppointments();
        
        // 3. Set Data in Request
        request.setAttribute("appointmentsList", appointments);
        
        // 4. Forward to the JSP (Internal redirect, URL stays viewAppointmentsCounselor.jsp)
        request.getRequestDispatcher("viewAppointmentsCounselor.jsp").forward(request, response);
        
        /*try (Connection conn = DriverManager.getConnection(dbURL, "app", "app")) {
            if ("markDone".equals(action) && appId != null) {
                PreparedStatement ps = conn.prepareStatement("UPDATE APPOINTMENT SET STATUSBOOKING = 'Done' WHERE APPOINTMENTID = ?");
                ps.setString(1, appId);
                ps.executeUpdate();
            }
            
            String sql = "SELECT A.APPOINTMENTID, S.NAMESTUD, A.DATEAPPOINTMENT, A.TIME, A.STATUSBOOKING " +
                         "FROM APPOINTMENT A JOIN STUDENT S ON A.STUDENTID = S.STUDENTID ORDER BY A.DATEAPPOINTMENT DESC";
            ResultSet rs = conn.createStatement().executeQuery(sql);
            request.setAttribute("appointments", rs);
            request.getRequestDispatcher("viewAppointmentsCounselor.jsp").forward(request, response);
        } catch (Exception e) { e.printStackTrace(); }*/
    }
}