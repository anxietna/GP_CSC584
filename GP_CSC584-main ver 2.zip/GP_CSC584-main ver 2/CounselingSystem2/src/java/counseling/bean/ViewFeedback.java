package counseling.bean;

import java.sql.Date;

public class ViewFeedback {

    private String studentName;
    private int rating;
    private String comment;
    private Date feedbackDate;

    public String getStudentName() { 
        return studentName;
    }
    
    public void setStudentName(String studentName) { 
        this.studentName = studentName; 
    }

    public int getRating() { 
        return rating; 
    }
    
    public void setRating(int rating) { 
        this.rating = rating;
    }

    public String getComment() { 
        return comment;
    }
    
    public void setComment(String comment) { 
        this.comment = comment; 
    }

    public Date getFeedbackDate() {
        return feedbackDate; 
    }
    
    public void setFeedbackDate(Date feedbackDate) {
        this.feedbackDate = feedbackDate;
    }
}