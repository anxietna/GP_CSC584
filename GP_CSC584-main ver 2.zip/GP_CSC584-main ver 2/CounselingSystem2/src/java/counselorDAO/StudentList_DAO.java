package counselorDAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class StudentList_DAO {
    private final String dbURL = "jdbc:derby://localhost:1527/counselingDB";
    private final String dbUser = "app";
    private final String dbPass = "app";

    public List<Map<String, String>> getAllStudents() {
        List<Map<String, String>> studentList = new ArrayList<>();
        String sql = "SELECT STUDENTID, NAMESTUD, MAJORSTUD, EMAILSTUD FROM STUDENT ORDER BY NAMESTUD ASC";

        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            try (Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPass);
                 Statement st = conn.createStatement();
                 ResultSet rs = st.executeQuery(sql)) {

                while (rs.next()) {
                    Map<String, String> student = new HashMap<>();
                    student.put("STUDENTID", rs.getString("STUDENTID"));
                    student.put("NAMESTUD", rs.getString("NAMESTUD"));
                    student.put("MAJORSTUD", rs.getString("MAJORSTUD"));
                    student.put("EMAILSTUD", rs.getString("EMAILSTUD"));
                    studentList.add(student);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return studentList;
    }
}