package counselorDAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.Statement;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import counseling.bean.ViewFeedback;

public class ViewFeedback_DAO {
    
    
    private final String dbURL = "jdbc:derby://localhost:1527/counselingDB";
    private final String dbUser = "app";
    private final String dbPass = "app";

    public List<ViewFeedback> getAllFeedback() {

    List<ViewFeedback> list = new ArrayList<>();

    try {
        Connection conn = DriverManager.getConnection(
            "jdbc:derby://localhost:1527/counselingDB", "app", "app");

        String sql = "SELECT S.NAMESTUD, F.RATING, F.COMMENT, F.FEEDBACKDATE " +
                     "FROM FEEDBACK F " +
                     "JOIN APPOINTMENT A ON F.APPOINTMENTID = A.APPOINTMENTID " +
                     "JOIN STUDENT S ON A.STUDENTID = S.STUDENTID " +
                     "WHERE A.STATUSBOOKING = 'Done'";

        Statement stmt = conn.createStatement();
        ResultSet rs = stmt.executeQuery(sql);

        while (rs.next()) {
            ViewFeedback fb = new ViewFeedback();
            fb.setStudentName(rs.getString("NAMESTUD"));
            fb.setRating(rs.getInt("RATING"));
            fb.setComment(rs.getString("COMMENT"));
            fb.setFeedbackDate(rs.getDate("FEEDBACKDATE"));

            list.add(fb);
        }

        conn.close();

    } catch (Exception e) {
        e.printStackTrace();
    }

    return list;
    }
    
    public boolean hasSubmittedFeedback(String appointmentID) {
        

    boolean submitted = false;

    try {
         Connection conn = DriverManager.getConnection(
            "jdbc:derby://localhost:1527/counselingDB", "app", "app");
         

        String sql = "SELECT 1 FROM FEEDBACK WHERE APPOINTMENTID = ?";
        PreparedStatement ps = conn.prepareStatement(sql);
        ps.setString(1, appointmentID);

        ResultSet rs = ps.executeQuery();

        if (rs.next()) {
            submitted = true;
        }

        conn.close();

    } catch (Exception e) {
        e.printStackTrace();
    }

    return submitted;
    }
}