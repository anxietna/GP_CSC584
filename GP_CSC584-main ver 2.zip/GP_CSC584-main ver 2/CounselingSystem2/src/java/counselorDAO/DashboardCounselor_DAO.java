package counselorDAO;
import java.sql.*;
import java.util.HashMap;
import java.util.Map;

public class DashboardCounselor_DAO {
    private final String dbURL = "jdbc:derby://localhost:1527/counselingDB";
    private final String dbUser = "app";
    private final String dbPass = "app";

    // Currently returns basic info, can be expanded for stats/counts later
    public Map<String, Object> getDashboardStats(String counselorID) {
        Map<String, Object> stats = new HashMap<>();
        try {
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            try (Connection conn = DriverManager.getConnection(dbURL, dbUser, dbPass)) {
                // Ex: add logic here later to count pending appointments
                // String sql = "SELECT COUNT(*) FROM appointment WHERE counselorID = ? AND statusBooking = 'Pending'";
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return stats;
    }
}
