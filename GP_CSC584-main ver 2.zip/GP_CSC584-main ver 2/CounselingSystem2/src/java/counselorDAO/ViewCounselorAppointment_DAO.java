package counselorDAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ViewCounselorAppointment_DAO {
    private final String dbURL = "jdbc:derby://localhost:1527/counselingDB";
    private final String dbUser = "app";
    private final String dbPass = "app";

    private Connection getConnection() throws SQLException, ClassNotFoundException {
        Class.forName("org.apache.derby.jdbc.ClientDriver");
        return DriverManager.getConnection(dbURL, dbUser, dbPass);
    }

    public List<Map<String, Object>> getAllAppointments() {
        List<Map<String, Object>> list = new ArrayList<>();
        String sql = "SELECT A.APPOINTMENTID, S.NAMESTUD, A.DATEAPPOINTMENT, A.TIME, A.STATUSBOOKING " +
                     "FROM APPOINTMENT A JOIN STUDENT S ON A.STUDENTID = S.STUDENTID ORDER BY A.DATEAPPOINTMENT DESC";
        
        try (Connection conn = getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            
            while (rs.next()) {
                Map<String, Object> row = new HashMap<>();
                row.put("APPOINTMENTID", rs.getString("APPOINTMENTID"));
                row.put("NAMESTUD", rs.getString("NAMESTUD"));
                row.put("DATEAPPOINTMENT", rs.getDate("DATEAPPOINTMENT"));
                row.put("TIME", rs.getString("TIME"));
                row.put("STATUSBOOKING", rs.getString("STATUSBOOKING"));
                list.add(row);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public void updateStatusToDone(String appId) {
        String sql = "UPDATE APPOINTMENT SET STATUSBOOKING = 'Done' WHERE APPOINTMENTID = ?";
        try (Connection conn = getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            ps.setString(1, appId);
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
