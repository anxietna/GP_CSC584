import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import counseling.bean.FeedbackBean;
import studentDAO.StudentFeedback_DAO;


@WebServlet("/StudentFeedbackServlet")
public class StudentFeedbackServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {


        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userID") == null) {
            response.sendRedirect("index.jsp?error=login");
            return;
        }
        
        String studID = (String) session.getAttribute("userID");


        StudentFeedback_DAO dao = new StudentFeedback_DAO();
        List<FeedbackBean> feedbackList = dao.getFeedbackByStudent(studID);

        request.setAttribute("feedbackList", feedbackList);
        request.setAttribute("status", "success");


        request.getRequestDispatcher("/studentFeedback.jsp")
                .forward(request, response);
    }
}


