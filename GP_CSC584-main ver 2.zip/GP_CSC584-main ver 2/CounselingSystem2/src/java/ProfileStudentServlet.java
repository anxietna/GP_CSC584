import java.io.IOException;
import java.sql.*;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import studentDAO.ProfileStudent_DAO;

@WebServlet("/ProfileStudentServlet")
public class ProfileStudentServlet extends HttpServlet {


    protected void doGet(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

    HttpSession session = request.getSession();
    String userID = (String) session.getAttribute("userID");

    if (userID == null) {
        response.sendRedirect("index.jsp?error=login");
        return;
    }

    ProfileStudent_DAO dao = new ProfileStudent_DAO();
    Map<String, String> profile = dao.getStudentProfile(userID);

    if (profile != null) {
        session.setAttribute("studentName", profile.get("studentName"));
        session.setAttribute("studentEmail", profile.get("studentEmail"));
        session.setAttribute("studentPassword", profile.get("studentPassword"));
    }

    request.getRequestDispatcher("profileStudent.jsp").forward(request, response);
}

    
     protected void doPost(HttpServletRequest request, HttpServletResponse response)
        throws ServletException, IOException {

    HttpSession session = request.getSession(false);
    if (session == null || session.getAttribute("userID") == null) {
        response.sendRedirect("index.jsp?error=login");
        return;
    }

    String userID = (String) session.getAttribute("userID");
    String newName = request.getParameter("name");
    String newEmail = request.getParameter("email");
    String newPass = request.getParameter("password");

    ProfileStudent_DAO dao = new ProfileStudent_DAO();
    boolean success = dao.updateProfile(userID, newName, newEmail, newPass);

    if (success) {
        session.setAttribute("userName", newName);
        session.setAttribute("studentName", newName);
        session.setAttribute("studentEmail", newEmail);
        session.setAttribute("studentPassword", newPass);
        response.sendRedirect("ProfileStudentServlet?update=success");
    } else {
        response.sendRedirect("ProfileStudentServlet?update=error");
    }
}

}
     