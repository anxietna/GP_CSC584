import java.io.IOException;
import java.util.List;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import counseling.bean.ViewFeedback;
import counselorDAO.ViewFeedback_DAO;


@WebServlet("/ViewFeedbackServlet")
public class ViewFeedbackServlet extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Session check
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("userID") == null) {
            response.sendRedirect("index.jsp?error=login");
            return;
        }

        // 2Call DAO
        ViewFeedback_DAO dao = new ViewFeedback_DAO();
        List<ViewFeedback> feedbackList = dao.getAllFeedback();

        // Pass data to JSP
        request.setAttribute("feedbackList", feedbackList);
        request.setAttribute("status", "success");

        // Forward to JSP (URL STAYS .jsp)
        request.getRequestDispatcher("/viewFeedback.jsp")
               .forward(request, response);
    }
}
