import java.io.IOException;
import java.sql.*;
import java.util.Map;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import studentDAO.dashboardStudent_DAO;

@WebServlet("/DashboardStudentServlet")
public class DashboardStudentServlet extends HttpServlet {
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        HttpSession session = request.getSession();
        String userID = (String) session.getAttribute("userID");
        String userRole = (String) session.getAttribute("userRole");

        // Security Check
        if (userID == null || !"Student".equals(userRole)) {
            response.sendRedirect("index.jsp?error=login");
            return;
        }
        
        dashboardStudent_DAO dao = new dashboardStudent_DAO();
        Map<String, Object> data= dao.getDashboardData(userID);
        
        if(data != null){
            for(Map.Entry<String, Object> entry: data.entrySet()){
                session.setAttribute(entry.getKey(), entry.getValue());
            }
        }
        
        response.sendRedirect("dashboardStudent.jsp");

    }  
}