import java.io.IOException;
import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import studentDAO.feedbackDAO;

@WebServlet(name = "SubmitFeedbackServlet", urlPatterns = {"/SubmitFeedbackServlet"})
public class SubmitFeedbackServlet extends HttpServlet {



    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {


        response.sendRedirect(request.getContextPath() + "/studentFeedback.jsp");
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String appID = request.getParameter("appointmentID");
        String ratingStr = request.getParameter("rating");
        String comment = request.getParameter("comment");
        

        if (appID == null || ratingStr == null || comment == null) {
            response.sendRedirect("feedback.jsp?appointmentID=" + appID + "&status=error");
            return;
        }

        int rating = Integer.parseInt(ratingStr);
        
        feedbackDAO dao = new feedbackDAO();
        boolean success = dao.saveOrUpdateFeedback(appID, rating, comment);
        

        if(success){
            response.sendRedirect(request.getContextPath() + "/studentFeedback.jsp?status=success");
            
        }else {
            response.sendRedirect("feedback.jsp?appointmentID=" + appID + "&status=error");
        }
        
  
    }
}
